package model;

public class Trucks {
	
	int id;
	int licence_number;
	String brand;
	String model;
	int max_load;
	int current_trailer_id;
	int current_driver_id;


}
