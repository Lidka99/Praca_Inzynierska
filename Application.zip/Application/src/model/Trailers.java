package model;

public class Trailers {

	int id;
	int trailer_number;
	int trailer_type;
}
