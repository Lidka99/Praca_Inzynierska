package model;

public class Drivers {

	int id;
	String name;
	String surname;
	String driving_licence;
	
}
