package model;
import java.util.Date;

public class Schedule {
	
	int id;
	Date date;
	Date arrival_date;
	int trailer_id;
	int truck_id;
	
	

}
