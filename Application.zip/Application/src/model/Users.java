package model;

public class Users {
	
	int id;
	String role;
	String name;
	String surname;
	String username;
	String password_hash;

}
